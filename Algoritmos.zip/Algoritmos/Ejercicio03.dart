// Ejercicio 3: Calcular el total ganado por un vendedor con sueldo base y comisiones.
import 'dart:io'; // Se importa para leer datos desde el teclado

void main() {
  // Se piden los valores al usuario
  print('Digite el ingreso base del vendedor:');
  double ingresoFijo = double.parse(stdin.readLineSync()!);

  print('Digite la suma total de las ventas realizadas:');
  double montoOperado = double.parse(stdin.readLineSync()!);

  // Se calcula la comisión (cambiado del 10% a 12%)
  double incentivo = montoOperado * 0.12;
  double pagoFinal = ingresoFijo + incentivo;

  // Se muestran los resultados
  print('El valor total de comisiones es: $incentivo');
  print('El monto total a recibir es: $pagoFinal');
}
