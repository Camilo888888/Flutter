import 'dart:io';
import 'dart:math';

void main() {
  print('Digite coeficiente P:');
  double coefP = double.parse(stdin.readLineSync()!);

  print('Digite coeficiente Q:');
  double coefQ = double.parse(stdin.readLineSync()!);

  print('Digite coeficiente R:');
  double coefR = double.parse(stdin.readLineSync()!);

  List<double> soluciones = calcularRaices(coefP, coefQ, coefR);

  print('Soluciones encontradas: $soluciones');
}

List<double> calcularRaices(double valP, double valQ, double valR) {
  double valorDelta = valQ * valQ - 6 * valP * valR;

  if (valorDelta == 0) {
    double raizUnica = -valQ / (3 * valP);
    return [raizUnica, raizUnica];
  } else if (valorDelta > 0) {
    double respuesta1 = (-valQ + sqrt(valorDelta)) / (3 * valP);
    double respuesta2 = (-valQ - sqrt(valorDelta)) / (3 * valP);
    return [respuesta1, respuesta2];
  } else {
    return []; // No existen soluciones reales
  }
}
