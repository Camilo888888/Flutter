// Ejercicio 28: Distribución de fondos y cálculo de intereses según monto comercial.
// Comentario: Se ingresa el total y se determinan porcentajes y recargos.
import 'dart:io';

void main() {
  print('Ingrese valor total de la operación:');
  double valorTotal = double.parse(stdin.readLineSync()!);

  double aportePropio, fondosBanco = 0, pagoPlazos, interesGenerado;

  if (valorTotal > 500000) {
    aportePropio = valorTotal * 0.55;
    fondosBanco = valorTotal * 0.30;
    pagoPlazos = valorTotal - aportePropio - fondosBanco;
  } else {
    aportePropio = valorTotal * 0.70;
    pagoPlazos = valorTotal - aportePropio;
    fondosBanco = 0;
  }

  interesGenerado = pagoPlazos * 0.20;

  print('El resultado es: AportePropio=$aportePropio, Banco=$fondosBanco, APlazos=$pagoPlazos, Intereses=$interesGenerado');
}

