// Ejercicio 25: Incrementar salario según tramo establecido.
// Si es menor a 52000 aumenta 18%, en caso contrario aumenta 14%.
import 'dart:io';

void main() {
  print('Ingrese salario actual:');
  double ingresoBase = double.parse(stdin.readLineSync()!);

  double salarioFinal = ingresoBase < 52000
      ? ingresoBase * 1.18
      : ingresoBase * 1.14;

  print('El resultado es: Salario actualizado = $salarioFinal');
}
