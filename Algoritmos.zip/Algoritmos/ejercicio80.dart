// Ejercicio 80: Estadísticas OCEI Venezuela
// La Oficina Central de Estadística e Informática (OCEI) desea conocer cierta información sobre la
// situación actual del país en cuanto a los niveles actuales de desempleo, analfabetismo y del potencial
// de profesionales existentes en Venezuela. Los Estados son identificados por un código entero
// positivo de dos (02) dígitos significativos. Las ciudades mediante un código de cuatro (04) dígitos
// significativos, de los cuales los dos últimos dígitos corresponden al Estado al cual pertenecen. Los
// municipios se identifican con un código de cuatro (06) dígitos significativos, de los cuales los primeros
// dígitos corresponden al código de Estado y los dos siguientes dígitos a los dos primeros dígitos del
// código de la ciudad en la cual están ubicados. Los datos fueron tomados de personas mayores de 18
// años y los mismos son los siguientes: edad; nivel de educación (N: ninguna, B: básica, S: secundaria,
// P: profesional); situación actual (D: desempleado, E: empleado). Se requiere que desarrolle un
// programa que cumpla con lo siguiente:
// • Determinar e imprimir por municipio el código y la cantidad de personas con las siguientes
// características: desempleado, sin ningún nivel de educación y mayores de 25 años.
// • Calcular e imprimir el código de las ciudades cuyas personas establecidas en la parte anterior sean
// más del 50%.
// • Calcular e imprimir el código del Estado con mayor porcentaje de profesionales desempleados.

import 'dart:io';

void main() {
  print('Ingrese número de personas:');
  int n = int.parse(stdin.readLineSync()!);

  Map<String, int> municipioDesempSinEdu = {};
  Map<String, int> municipioTotal = {};
  Map<String, int> ciudadDesempSinEdu = {};
  Map<String, int> ciudadTotal = {};
  Map<String, int> estadoProfDesemp = {};
  Map<String, int> estadoProfTotal = {};

  for (int i = 0; i < n; i++) {
    print('Persona ${i + 1}: código municipio (6 dígitos), edad, nivel educación (N/B/S/P), situación (D/E):');
    List<String> input = stdin.readLineSync()!.split(' ');
    String munCode = input[0];
    int edad = int.parse(input[1]);
    String edu = input[2];
    String sit = input[3];

    String estadoCode = munCode.substring(0, 2);
    String ciudadCode = munCode.substring(0, 4);

    municipioTotal[munCode] = (municipioTotal[munCode] ?? 0) + 1;
    ciudadTotal[ciudadCode] = (ciudadTotal[ciudadCode] ?? 0) + 1;

    if (sit == 'D' && edu == 'N' && edad > 25) {
      municipioDesempSinEdu[munCode] = (municipioDesempSinEdu[munCode] ?? 0) + 1;
      ciudadDesempSinEdu[ciudadCode] = (ciudadDesempSinEdu[ciudadCode] ?? 0) + 1;
    }

    if (edu == 'P') {
      estadoProfTotal[estadoCode] = (estadoProfTotal[estadoCode] ?? 0) + 1;
      if (sit == 'D') {
        estadoProfDesemp[estadoCode] = (estadoProfDesemp[estadoCode] ?? 0) + 1;
      }
    }
  }

  // Por municipio
  print('\nPor municipio (desempleados sin educación >25 años):');
  for (String mun in municipioDesempSinEdu.keys) {
    print('Municipio $mun: ${municipioDesempSinEdu[mun]}');
  }

  // Ciudades >50%
  print('\nCiudades con >50% de esos casos:');
  for (String ciu in ciudadDesempSinEdu.keys) {
    int totalCiu = ciudadTotal[ciu] ?? 0;
    int desempCiu = ciudadDesempSinEdu[ciu] ?? 0;
    double pct = (desempCiu / totalCiu) * 100;
    if (pct > 50) {
      print('Ciudad $ciu');
    }
  }

  // Estado con mayor % profesionales desempleados
  String maxEstado = '';
  double maxPct = 0;
  for (String est in estadoProfTotal.keys) {
    int totalProf = estadoProfTotal[est] ?? 0;
    int desempProf = estadoProfDesemp[est] ?? 0;
    if (totalProf > 0) {
      double pct = (desempProf / totalProf) * 100;
      if (pct > maxPct) {
        maxPct = pct;
        maxEstado = est;
      }
    }
  }
  print('\nEstado con mayor % profesionales desempleados: $maxEstado (${maxPct.toStringAsFixed(2)}%)');
}
