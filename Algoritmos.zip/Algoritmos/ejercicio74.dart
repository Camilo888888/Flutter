// Ejercicio 74: Producción de bloquera
// La bloquera “El Milagro” es una pequeña empresa dedicada a la fabricación de bloques de cemento
// para construcción. Actualmente cuenta con una plantilla de obreros, cada uno de los cuales tiene un
// número X de unidades a producir por semana. La secretaria registra, cada día, el número de bloques
// que produjo cada obrero, para totalizar el sábado lo producido en la semana. De cada obrero se
// conoce: nombre y cantidad de unidades producidas por día. Desarrolle un programa, que calcule y
// muestre:
// • Por obrero:
// o Nombre
// o Total, producido en la semana.
// o Porcentaje que representa la producción semanal, respecto al límite establecido.
// • En general:
// o Porcentaje de obreros que alcanzaron o superaron el número de unidades producidas
// establecidas.
// o Nombre del obrero que más produjo y cantidad producida.
// o Promedio de producción de la bloquera en la semana.

import 'dart:io';

void main() {
  print('Ingrese número de obreros:');
  int n = int.parse(stdin.readLineSync()!);
  print('Ingrese límite semanal por obrero:');
  int limite = int.parse(stdin.readLineSync()!);

  List<String> nombres = [];
  List<int> producciones = [];
  int totalBloquera = 0;
  int maxProd = 0;
  String maxNombre = '';

  for (int i = 0; i < n; i++) {
    print('Obrero ${i + 1}: nombre y producción semanal:');
    List<String> input = stdin.readLineSync()!.split(' ');
    String nombre = input[0];
    int prod = int.parse(input[1]);
    nombres.add(nombre);
    producciones.add(prod);
    totalBloquera += prod;
    if (prod > maxProd) {
      maxProd = prod;
      maxNombre = nombre;
    }
  }

  int alcanzaron = producciones.where((p) => p >= limite).length;
  double pctAlcanzaron = (alcanzaron / n) * 100;
  double avgBloquera = totalBloquera / n;

  for (int i = 0; i < n; i++) {
    double pct = (producciones[i] / limite) * 100;
    print('Obrero: ${nombres[i]}, Total: ${producciones[i]}, Porcentaje: ${pct.toStringAsFixed(2)}%');
  }

  print('Porcentaje que alcanzaron: ${pctAlcanzaron.toStringAsFixed(2)}%');
  print('Obrero que más produjo: $maxNombre, Cantidad: $maxProd');
  print('Promedio bloquera: ${avgBloquera.toStringAsFixed(2)}');
}
