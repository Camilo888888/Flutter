// Ejercicio 39: Elegir entre adquirir un vehículo o un lote según pérdida y ganancia estimada.
// Comentario: Se ingresan porcentajes proyectados en un periodo de 3 ciclos.

import 'dart:io';

void main() {
  print('Indique el % de depreciación del vehículo en 3 ciclos (ej: 28 para 28%):');
  double pPerdidaVeh = double.parse(stdin.readLineSync()!);

  print('Indique el % de valorización del lote en 3 ciclos (ej: 55 para 55%):');
  double pGananciaLote = double.parse(stdin.readLineSync()!);

  // Decisión: se adquiere vehículo si su depreciación no supera la mitad del incremento del lote
  if (pPerdidaVeh <= (pGananciaLote / 2)) {
    print('El resultado final es: Conviene adquirir el vehículo');
  } else {
    print('El resultado final es: No conviene adquirir el vehículo');
  }
}
