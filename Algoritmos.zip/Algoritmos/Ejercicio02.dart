// Ejercicio 2: Calcular cuánto dinero gana una persona en un mes si el banco paga 2% mensual.
void main() {
  // Se asigna el capital inicial
  double montoBase = 8500;

  // Se calcula la ganancia del 2% mensual
  double incrementoMensual = montoBase * 0.03;

  // Se muestra la ganancia
  print('La ganancia después de un mes es: $incrementoMensual');
}
