// Ejercicio 20: Calcular la tasa anual dada una inversión inicial y el total de intereses generados en cierto periodo.
// Comentario: Fórmula del interés simple: I = (Inversion * Periodo * Tasa)/100 -> despejar Tasa.
import 'dart:io';

void main() {
  print('Digite el monto inicial:');
  double montoBase = double.parse(stdin.readLineSync()!);

  print('Digite los intereses obtenidos en 5 años:');
  double ganancia = double.parse(stdin.readLineSync()!);

  double periodo = 5;
  double tasaAnual = (ganancia * 100) / (montoBase * periodo);

  print('El resultado es: Tasa anual = $tasaAnual%');
}
