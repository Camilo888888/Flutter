// Ejercicio 65: Cálculo de sueldo neto de trabajadores
// Calcular el sueldo neto de los trabajadores de una compañía sabiendo que este depende de los
// siguientes datos:
// • sueldo básico mensual 100000 si es obrero
// • sueldo básico mensual 165500 si es administrativo
// • sueldo básico mensual 250000 si es ejecutivo
// Las asignaciones y deducciones son:
// • aporte por cada hijo hasta 5 hijos 10% del sueldo básico
// • aporte por asistencia superior al 95% de los 30 días del mes 5% del sueldo básico.
// • Deducción del 10% del sueldo básico para la caja de ahorros.
// • Deducción para el seguro social 2% del sueldo básico
// Por cada empleado debe salir un registro con el nombre y cédula, sueldo básico, aporte a la Caja de
// Ahorros, seguro social y sueldo neto.

import 'dart:io';

void main() {
  print('Ingrese el número de empleados:');
  int n = int.parse(stdin.readLineSync()!);

  for (int i = 0; i < n; i++) {
    print('Empleado ${i + 1}:');
    print('Nombre:');
    String nombre = stdin.readLineSync()!;
    print('Cédula:');
    String cedula = stdin.readLineSync()!;
    print('Tipo (O=obrero, A=administrativo, E=ejecutivo):');
    String tipo = stdin.readLineSync()!.toUpperCase();
    print('Número de hijos (hasta 5):');
    int hijos = int.parse(stdin.readLineSync()!);
    print('Días asistidos en el mes:');
    int diasAsistidos = int.parse(stdin.readLineSync()!);

    double sueldoBasico;
    if (tipo == 'O') sueldoBasico = 100000;
    else if (tipo == 'A') sueldoBasico = 165500;
    else sueldoBasico = 250000;

    double aporteHijos = hijos * 0.1 * sueldoBasico;
    double aporteAsistencia = diasAsistidos > 28.5 ? 0.05 * sueldoBasico : 0; // 95% de 30 días
    double cajaAhorros = 0.1 * sueldoBasico;
    double seguroSocial = 0.02 * sueldoBasico;

    double sueldoNeto = sueldoBasico + aporteHijos + aporteAsistencia - cajaAhorros - seguroSocial;

    print('\nRegistro del empleado:');
    print('Nombre: $nombre');
    print('Cédula: $cedula');
    print('Sueldo básico: \$${sueldoBasico.toStringAsFixed(2)}');
    print('Aporte a Caja de Ahorros: \$${cajaAhorros.toStringAsFixed(2)}');
    print('Seguro social: \$${seguroSocial.toStringAsFixed(2)}');
    print('Sueldo neto: \$${sueldoNeto.toStringAsFixed(2)}\n');
  }
}
