// Ejercicio 67: Pagos crecientes de deuda
// Una persona adquiere una deuda de Bs. 12775, la cual cancela mediante pagos de montos crecientes
// de los cuales el primero es por Bs. 100 y además la diferencia de dos pagos consecutivos es Bs. 125.
// Determinar el número de pagos que realiza la persona así como el monto del último pago. Muestre
// en pantalla una tabla con el monto de cada pago y el monto pendiente por cancelar. Respuesta:
// número pagos = 14, monto del último = 1725.

void main() {
  double deuda = 12775;
  double pagoInicial = 100;
  double diferencia = 125;
  double pendiente = deuda;
  int numPagos = 0;
  double pagoActual = pagoInicial;

  print('Pago\tMonto\tPendiente');
  while (pendiente > 0) {
    numPagos++;
    double montoPago = pagoActual;
    if (montoPago > pendiente) montoPago = pendiente;
    pendiente -= montoPago;
    print('$numPagos\t\$${montoPago.toStringAsFixed(2)}\t\$${pendiente.toStringAsFixed(2)}');
    pagoActual += diferencia;
  }

  double ultimoPago = pagoActual - diferencia;
  print('\nNúmero de pagos: $numPagos');
  print('Monto del último pago: \$${ultimoPago.toStringAsFixed(2)}');
}
