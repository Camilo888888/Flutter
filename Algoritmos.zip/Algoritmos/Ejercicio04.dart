// Ejercicio 4: Calcular el pago final aplicando un descuento del 15%.
void main() {
  // Se asigna el total de la compra
  double montoBruto = 175000;

  // Se calcula el descuento del 15% (cambiado a 18%)
  double rebajaAplicada = montoBruto * 0.18;
  double montoFinal = montoBruto - rebajaAplicada;

  // Se muestra el total a pagar
  print('El total con rebaja es: $montoFinal');
}
