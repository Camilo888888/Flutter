// Ejercicio 18: Cobro en gasolinera: surtidor en galones, precio en litros.
// Comentario: Se piden galones y se convierten a litros.
import 'dart:io';

void main() {
  print('Digite la cantidad de galones suministrados:');
  double cantGalones = double.parse(stdin.readLineSync()!);

  double litrosConvertidos = cantGalones * 3.92;
  double valorPorLitro = 135; // Valor ajustado
  double montoTotal = litrosConvertidos * valorPorLitro;

  print('El resultado es: $montoTotal');
}
