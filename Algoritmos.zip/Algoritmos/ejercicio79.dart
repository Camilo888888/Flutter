// Ejercicio 79: Estadísticas de libros en biblioteca
// Se desea obtener estadísticas sobre los libros de una biblioteca. Para cada libro se conoce: título,
// autor, género, año de publicación, número de páginas. Se pide calcular y mostrar:
// a. El libro con más páginas (título y autor).
// b. El libro con menos páginas (título y autor).
// c. El promedio de páginas de los libros.
// d. El porcentaje de libros por género.
// e. El género con más libros.
// f. El promedio de años de publicación.

import 'dart:io';

void main() {
  print('Ingrese número de libros:');
  int n = int.parse(stdin.readLineSync()!);

  List<String> titulos = [];
  List<String> autores = [];
  List<String> generos = [];
  List<int> anos = [];
  List<int> paginas = [];

  for (int i = 0; i < n; i++) {
    print('Libro ${i + 1}: título, autor, género, año, páginas:');
    List<String> input = stdin.readLineSync()!.split(' ');
    titulos.add(input[0]);
    autores.add(input[1]);
    generos.add(input[2]);
    anos.add(int.parse(input[3]));
    paginas.add(int.parse(input[4]));
  }

  int maxPag = paginas.reduce((a, b) => a > b ? a : b);
  int minPag = paginas.reduce((a, b) => a < b ? a : b);
  int idxMax = paginas.indexOf(maxPag);
  int idxMin = paginas.indexOf(minPag);

  double avgPag = paginas.reduce((a, b) => a + b) / n;

  Map<String, int> generoCount = {};
  for (String g in generos) {
    generoCount[g] = (generoCount[g] ?? 0) + 1;
  }
  String maxGenero = generoCount.keys.reduce((a, b) => generoCount[a]! > generoCount[b]! ? a : b);

  double avgAno = anos.reduce((a, b) => a + b) / n;

  print('Más páginas: ${titulos[idxMax]} ${autores[idxMax]}');
  print('Menos páginas: ${titulos[idxMin]} ${autores[idxMin]}');
  print('Promedio páginas: ${avgPag.toStringAsFixed(2)}');
  print('Porcentajes por género:');
  for (String g in generoCount.keys) {
    double pct = (generoCount[g]! / n) * 100;
    print('$g: ${pct.toStringAsFixed(2)}%');
  }
  print('Género con más libros: $maxGenero');
  print('Promedio años: ${avgAno.toStringAsFixed(2)}');
}
