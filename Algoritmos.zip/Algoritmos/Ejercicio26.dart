// Ejercicio 26: Evaluación de expresiones en función del valor de R.
// Comentario: Según el valor de R, se aplica la operación correspondiente.
import 'dart:io';
import 'dart:math';

void main() {
  print('Ingrese X:');
  double X = double.parse(stdin.readLineSync()!);
  print('Ingrese Y:');
  double Y = double.parse(stdin.readLineSync()!);
  print('Ingrese Z:');
  double Z = double.parse(stdin.readLineSync()!);
  print('Ingrese R:');
  double R = double.parse(stdin.readLineSync()!);

  double salida;
  if (R == 0) {
    salida = pow((X - Z), 2).toDouble();
  } else if (R > 0) {
    salida = pow((X - Y), 3).toDouble() / R;
  } else {
    salida = -1; // cambiado el valor del caso negativo
  }

  print('El resultado es: $salida');
}
