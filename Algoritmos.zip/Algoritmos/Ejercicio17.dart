// Ejercicio 17: Calcular porcentaje de descuento dado precio final y PVP.
// Comentario: Se asignan valores modificados.
void main() {
  double valorFinal = 62;
  double precioBase = 140;

  double porcentajeDesc = ((precioBase - valorFinal) / precioBase) * 100;

  print('El resultado es: $porcentajeDesc% de descuento');
}
