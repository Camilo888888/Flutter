// Ejercicio 12: Promedios en tres materias con porcentajes diferentes.
// Comentario: Se piden notas de tareas y exámenes por teclado.
import 'dart:io';

void main() {
  // Matemática
  print('Digite la nota del examen de Matemática:');
  double pruebaMat = double.parse(stdin.readLineSync()!);

  print('Digite el promedio de actividades de Matemática:');
  double actividadesMat = double.parse(stdin.readLineSync()!);

  // (antes 90% + 10%, ahora 85% + 15%)
  double resultadoMat = pruebaMat * 0.85 + actividadesMat * 0.15;

  // Física
  print('Digite la nota del examen de Física:');
  double pruebaFis = double.parse(stdin.readLineSync()!);

  print('Digite el promedio de actividades de Física:');
  double actividadesFis = double.parse(stdin.readLineSync()!);

  // (antes 80% + 20%, ahora 75% + 25%)
  double resultadoFis = pruebaFis * 0.75 + actividadesFis * 0.25;

  // Química
  print('Digite la nota del examen de Química:');
  double pruebaQui = double.parse(stdin.readLineSync()!);

  print('Digite el promedio de actividades de Química:');
  double actividadesQui = double.parse(stdin.readLineSync()!);

  // (antes 85% + 15%, ahora 88% + 12%)
  double resultadoQui = pruebaQui * 0.88 + actividadesQui * 0.12;

  double promedioTotal = (resultadoMat + resultadoFis + resultadoQui) / 3;

  print('Promedio final de Matemática: $resultadoMat');
  print('Promedio final de Física: $resultadoFis');
  print('Promedio final de Química: $resultadoQui');
  print('El promedio general del estudiante es: $promedioTotal');
}

