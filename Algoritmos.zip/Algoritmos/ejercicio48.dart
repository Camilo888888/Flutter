import 'dart:io';

void main() {
  print('Ingrese valor inicial:');
  int desde = int.parse(stdin.readLineSync()!);

  print('Ingrese valor final:');
  int hasta = int.parse(stdin.readLineSync()!);

  print('Ingrese incremento:');
  int incremento = int.parse(stdin.readLineSync()!);

  generarTabla(desde, hasta, incremento);
}

void generarTabla(int desde, int hasta, int incremento) {
  print('F\tC\tK\tR');

  for (int fahrenheit = desde; fahrenheit <= hasta; fahrenheit += incremento) {
    double celsius = 5 * (fahrenheit - 32) / 9;
    double rankine = fahrenheit + 459.67;
    double kelvin = celsius + 273.15;

    print(
      '$fahrenheit\t'
      '${celsius.toStringAsFixed(2)}\t'
      '${kelvin.toStringAsFixed(2)}\t'
      '${rankine.toStringAsFixed(2)}'
    );
  }
}
