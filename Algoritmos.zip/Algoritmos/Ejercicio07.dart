// Ejercicio 7: Convertir una cantidad en metros a pies y pulgadas.
import 'dart:io'; // Se importa para leer datos del usuario

void main() {
  // Se solicita la cantidad en metros
  print('Digite la distancia en metros:');
  double medidaMetros = double.parse(stdin.readLineSync()!);

  // Conversión según las equivalencias (modificadas)
  double valorPulgadas = medidaMetros * 38.45;
  double valorPies = valorPulgadas / 11.5;

  // Se muestran los resultados
  print('La medida corresponde a $valorPies pies y $valorPulgadas pulgadas.');
}
