/// Ejercicio 50:
/// Calcular y mostrar la suma de todos los números pares comprendidos entre 100 y 1000.

class SumaPares {
  final int rangoInicio;
  final int rangoFin;

  /// Constructor que establece el rango.
  SumaPares(this.rangoInicio, this.rangoFin);

  /// Método para calcular la suma de los números pares en el rango.
  int calcular() {
    int sumaTotal = 0;
    // Determinar el primer número par del rango
    int primerPar = rangoInicio.isEven ? rangoInicio : rangoInicio + 1;

    for (int numero = primerPar; numero <= rangoFin; numero += 2) {
      sumaTotal += numero;
    }
    return sumaTotal;
  }
}

void main() {
  const int rangoInicio = 100;
  const int rangoFin = 1000;

  final SumaPares calculador = SumaPares(rangoInicio, rangoFin);
  final int resultado = calculador.calcular();

  print('--- Ejercicio 50: Suma de Pares ---');
  print('Rango: $rangoInicio a $rangoFin');
  print('Suma de todos los números pares: $resultado');
}
