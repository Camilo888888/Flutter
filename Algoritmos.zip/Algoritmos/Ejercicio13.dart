// Ejercicio 13: Calcular cuánto dinero hay en un banco con billetes variados.
// Comentario: Se asignan números de billetes directamente para simplificar.
void main() {
  int bA = 3;  // billetes de 50000
  int bB = 1;  // 20000
  int bC = 4;  // 10000
  int bD = 2;  // 5000
  int bE = 6;  // 2000
  int bF = 8;  // 1000
  int bG = 12; // 500
  int bH = 15; // 100

  int montoTotal =
      bA * 50000 +
      bB * 20000 +
      bC * 10000 +
      bD * 5000 +
      bE * 2000 +
      bF * 1000 +
      bG * 500 +
      bH * 100;

  print('El total de dinero almacenado es: $montoTotal');
}

