// Ejercicio 23: Ingresos por tonelada procesada en productos derivados.
// Comentario: Se usan nuevos valores de ejemplo completamente modificados.
void main() {
  double H = 510; // kg producto A
  double L = 225; // litros producto B
  double C1 = 145; // precio paquete producto A (25kg)
  double C2 = 195; // precio caja producto B (12 envases)
  double C3 = 8.20; // precio venta al detal producto A por kg
  double C4 = 15.75; // precio venta al detal producto B por litro

  int paquetesA = (H / 25).floor();
  int cajasB = (L / 12).floor();
  double sobranteA = H - paquetesA * 25;
  double sobranteB = L - cajasB * 12;

  double ingresoTotal = paquetesA * C1 +
                        cajasB * C2 +
                        sobranteA * C3 +
                        sobranteB * C4;

  print('El resultado es: $ingresoTotal');
}
