// Ejercicio 75: Cambio de peso en club
// Cinco miembros de un club contra la obesidad desean saber cuánto han bajado o subido de peso
// desde la última vez que se reunieron. Para esto se debe realizar un ritual de pesaje en donde cada
// uno se pesa en diez básculas distintas para así tener el promedio más exacto de su peso. Si existe
// diferencia positiva entre este promedio de peso y el peso de la última vez que se reunieron,
// significa que subieron de peso. Pero si la diferencia es negativa, significa que bajaron. Lo que el
// problema requiere es que por cada persona se imprima un mensaje que diga SUBIO ó BAJO y la
// cantidad de kilos que subió o bajó de peso.

import 'dart:io';

void main() {
  for (int i = 0; i < 5; i++) {
    print('Persona ${i + 1}: peso anterior:');
    double pesoAnt = double.parse(stdin.readLineSync()!);
    print('Pesos en 10 básculas (separados por espacio):');
    List<String> pesosStr = stdin.readLineSync()!.split(' ');
    List<double> pesos = pesosStr.map(double.parse).toList();
    double promedio = pesos.reduce((a, b) => a + b) / 10;
    double diferencia = promedio - pesoAnt;
    String mensaje = diferencia > 0 ? 'SUBIO' : 'BAJO';
    print('$mensaje ${diferencia.abs().toStringAsFixed(2)} kilos');
  }
}
