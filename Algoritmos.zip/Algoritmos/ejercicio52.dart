// 52. Muestreo de peso por categorías etarias (niños, jóvenes, adultos, viejos)

/// Clase base para Persona
class Persona {
  final String nombre;
  final int edad;
  final double peso;

  Persona(this.nombre, this.edad, this.peso);
}

/// Clase para manejar la clasificación de edad
class ClasificadorEdad {
  static String categoria(int edad) {
    if (edad <= 12) return 'Niños';
    if (edad <= 25) return 'Jóvenes';
    if (edad <= 60) return 'Adultos';
    return 'Viejos';
  }
}

/// Clase para calcular promedios de peso
class CalculadoraPromedios {
  final List<Persona> _personas = [];

  void agregarPersona(Persona persona) => _personas.add(persona);

  Map<String, double> calcularPromedios() {
    final Map<String, double> suma = {'Niños': 0, 'Jóvenes': 0, 'Adultos': 0, 'Viejos': 0};
    final Map<String, int> conteo = {'Niños': 0, 'Jóvenes': 0, 'Adultos': 0, 'Viejos': 0};

    for (var p in _personas) {
      String cat = ClasificadorEdad.categoria(p.edad);
      suma[cat] = suma[cat]! + p.peso;
      conteo[cat] = conteo[cat]! + 1;
    }

    return {
      for (var cat in suma.keys)
        cat: conteo[cat]! > 0 ? suma[cat]! / conteo[cat]! : 0
    };
  }
}

void main() {
  final calc = CalculadoraPromedios();

  // Ejemplo: agregamos algunas personas
  calc.agregarPersona(Persona('Ana', 10, 35));
  calc.agregarPersona(Persona('Luis', 20, 68));
  calc.agregarPersona(Persona('Carla', 45, 72));
  calc.agregarPersona(Persona('Pedro', 70, 65));

  final promedios = calc.calcularPromedios();

  print('--- Ejercicio 52: Promedio de peso por categoría ---');
  print('Niños: ${promedios['Niños']} kg');
  print('Jóvenes: ${promedios['Jóvenes']} kg');
  print('Adultos: ${promedios['Adultos']} kg');
  print('Viejos: ${promedios['Viejos']} kg');
}
