// Ejercicio 37: Verificar si tres medidas construyen un triángulo, determinar tipo y calcular área.
// Comentario: Se ingresan 3 valores, se valida condición triangular y se clasifica.

import 'dart:io';
import 'dart:math';

void main() {
  print('Ingrese valor X:'); 
  double xL = double.parse(stdin.readLineSync()!);

  print('Ingrese valor Y:'); 
  double yL = double.parse(stdin.readLineSync()!);

  print('Ingrese valor Z:'); 
  double zL = double.parse(stdin.readLineSync()!);

  List<double> medidas = [xL, yL, zL]..sort();

  if (medidas[0] + medidas[1] <= medidas[2]) {
    print('El resultado es: No corresponde a un triángulo válido');
    return;
  }

  String claseTri;
  if (xL == yL && yL == zL) {
    claseTri = 'Regular';
  } else if (xL == yL || yL == zL || xL == zL) {
    claseTri = 'Semirregular';
  } else {
    claseTri = 'Irregular';
  }

  double semiP = (xL + yL + zL) / 2;
  double region = sqrt(semiP * (semiP - xL) * (semiP - yL) * (semiP - zL));

  print('El resultado es: Tipo=$claseTri, Área=$region');
}
