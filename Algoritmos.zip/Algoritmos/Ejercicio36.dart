// Ejercicio 36: Descomposición de un valor en billetes con nuevas denominaciones.
// Comentario: Uso de división entera y módulo con valores modificados.

void main() {
  int montoTotal = 987650; // nuevo ejemplo
  int saldo = montoTotal;

  int d60000 = saldo ~/ 60000; saldo %= 60000;
  int d25000 = saldo ~/ 25000; saldo %= 25000;
  int d15000 = saldo ~/ 15000; saldo %= 15000;
  int d7000 = saldo ~/ 7000; saldo %= 7000;
  int d3000 = saldo ~/ 3000; saldo %= 3000;
  int d1200 = saldo ~/ 1200; saldo %= 1200;
  int d600 = saldo ~/ 600; saldo %= 600;
  int d200 = saldo ~/ 200; saldo %= 200;
  int d80 = saldo ~/ 80; saldo %= 80;
  int d30 = saldo ~/ 30; saldo %= 30;
  int d5 = saldo ~/ 5; saldo %= 5;

  print('El resultado es: Desglose -> '
        '60000:$d60000, 25000:$d25000, 15000:$d15000, 7000:$d7000, '
        '3000:$d3000, 1200:$d1200, 600:$d600, 200:$d200, '
        '80:$d80, 30:$d30, 5:$d5');
}

