// Ejercicio 78: Estadísticas de empleados
// Se desea obtener estadísticas sobre los empleados de una empresa. Para cada empleado se conoce:
// nombre, edad, sexo, departamento, salario. Se pide calcular y mostrar:
// a. El empleado con el mayor salario (nombre y departamento).
// b. El empleado con el menor salario (nombre y departamento).
// c. El promedio de edad de los empleados.
// d. El porcentaje de empleados hombres y mujeres.
// e. El departamento con más empleados.
// f. El promedio general de los salarios.

import 'dart:io';

void main() {
  print('Ingrese número de empleados:');
  int n = int.parse(stdin.readLineSync()!);

  List<String> nombres = [];
  List<int> edades = [];
  List<String> sexos = [];
  List<String> depts = [];
  List<double> salarios = [];

  for (int i = 0; i < n; i++) {
    print('Empleado ${i + 1}: nombre, edad, sexo (M/F), departamento, salario:');
    List<String> input = stdin.readLineSync()!.split(' ');
    nombres.add(input[0]);
    edades.add(int.parse(input[1]));
    sexos.add(input[2]);
    depts.add(input[3]);
    salarios.add(double.parse(input[4]));
  }

  double maxSal = salarios.reduce((a, b) => a > b ? a : b);
  double minSal = salarios.reduce((a, b) => a < b ? a : b);
  int idxMax = salarios.indexOf(maxSal);
  int idxMin = salarios.indexOf(minSal);

  double avgEdad = edades.reduce((a, b) => a + b) / n;
  int hombres = sexos.where((s) => s == 'M').length;
  int mujeres = sexos.where((s) => s == 'F').length;
  double pctHombres = (hombres / n) * 100;
  double pctMujeres = (mujeres / n) * 100;

  Map<String, int> deptCount = {};
  for (String d in depts) {
    deptCount[d] = (deptCount[d] ?? 0) + 1;
  }
  String maxDept = deptCount.keys.reduce((a, b) => deptCount[a]! > deptCount[b]! ? a : b);

  double avgSal = salarios.reduce((a, b) => a + b) / n;

  print('Mayor salario: ${nombres[idxMax]} ${depts[idxMax]}');
  print('Menor salario: ${nombres[idxMin]} ${depts[idxMin]}');
  print('Promedio edad: ${avgEdad.toStringAsFixed(2)}');
  print('Porcentaje hombres: ${pctHombres.toStringAsFixed(2)}%, mujeres: ${pctMujeres.toStringAsFixed(2)}%');
  print('Departamento con más empleados: $maxDept');
  print('Promedio salario: ${avgSal.toStringAsFixed(2)}');
}
