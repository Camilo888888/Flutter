// Ejercicio 22: Calcular incremento porcentual al pagar en varias cuotas.
// Comentario: Se piden precio base y valor de la cuota (12 cuotas).
import 'dart:io';

void main() {
  print('Ingrese precio base (Q):');
  double Q = double.parse(stdin.readLineSync()!);
  print('Ingrese valor de la cuota mensual (M) (12 pagos):');
  double M = double.parse(stdin.readLineSync()!);

  double montoTotal = M * 14; // cambiado de 12 a 14 cuotas
  double incremento = ((montoTotal - Q) / Q) * 100;

  print('El resultado es: Incremento = $incremento%');
}
