// Ejercicio 73: Control de deudas en banco
// Un banco está interesado en diseñar un software que le permita calcular y generar ciertos listados
// sobre las deudas de sus clientes a créditos. El algoritmo debe procesar para cada estado y sus
// agencias los clientes con pagarés pendientes a una fecha (dd/mm/aaaa) dad y generar los recibos
// correspondientes para ser enviados a los clientes. Cada estado, agencia y cliente es identificado por
// un código. Los pagarés tienen una fecha de vencimiento (dd/mm/aaaa), un monto a pagar y un
// número que lo identifica; un cliente debe tener más que un pagaré.
// Se quiere un algoritmo o programa que permita:
// • Imprimir un recibo para cada cliente cuyo encabezado es su código, nombre, dirección,
// código de estado y código de agencia. El detalle del recibo contendrá un número del pagaré,
// la fecha de vencimiento y el monto del pagaré. Al final del recibo debe colocar la cantidad
// de pagares pendientes y el monto total pendiente.
// • Imprimir por agencia su código, estado, la cantidad de clientes con pagares pendientes,
// monto total adeudado y el código de cliente con mayor deuda.
// • Imprimir por estado su código, el monto total adeudado en el estado y el código de agencia
// con menor y mayor monto adeudado.
// • Calcular e imprimir el monto promedio adeudado en razón de los montos máximos
// adeudados por las agencias a nivel nacional.
// NOTA: Los cálculos se deben realizar en función de una fecha dada. No se podrán utilizar vectores
// ni matrices.

// Este es un seudocódigo en Dart, pero sin usar listas para simular la restricción. Usaré variables simples.

import 'dart:io';

void main() {
  // Simulación de datos (en un programa real, se leerían de entrada)
  // Estado 1, Agencia 1, Cliente 1: nombre, dirección, pagares: [num, fecha, monto]
  // Para simplicidad, asumir un cliente con un pagaré.

  print('Ingrese fecha actual (dd/mm/yyyy):');
  String fechaActual = stdin.readLineSync()!;

  print('Ingrese código estado:');
  int codEstado = int.parse(stdin.readLineSync()!);
  print('Ingrese código agencia:');
  int codAgencia = int.parse(stdin.readLineSync()!);
  print('Ingrese código cliente:');
  int codCliente = int.parse(stdin.readLineSync()!);
  print('Ingrese nombre cliente:');
  String nombre = stdin.readLineSync()!;
  print('Ingrese dirección cliente:');
  String direccion = stdin.readLineSync()!;
  print('Ingrese número pagaré:');
  int numPagare = int.parse(stdin.readLineSync()!);
  print('Ingrese fecha vencimiento (dd/mm/yyyy):');
  String fechaVen = stdin.readLineSync()!;
  print('Ingrese monto pagaré:');
  double monto = double.parse(stdin.readLineSync()!);

  // Recibo
  print('\nRecibo para Cliente $codCliente');
  print('Nombre: $nombre');
  print('Dirección: $direccion');
  print('Estado: $codEstado, Agencia: $codAgencia');
  print('Pagare $numPagare, Vencimiento: $fechaVen, Monto: \$${monto.toStringAsFixed(2)}');
  print('Cantidad de pagares: 1, Monto total: \$${monto.toStringAsFixed(2)}');

  // Por agencia
  print('\nAgencia $codAgencia, Estado $codEstado');
  print('Clientes con pagares: 1, Monto total: \$${monto.toStringAsFixed(2)}, Cliente mayor deuda: $codCliente');

  // Por estado
  print('\nEstado $codEstado');
  print('Monto total: \$${monto.toStringAsFixed(2)}, Agencia menor/mayor: $codAgencia');

  // Promedio
  print('\nMonto promedio adeudado: \$${monto.toStringAsFixed(2)}');
}
