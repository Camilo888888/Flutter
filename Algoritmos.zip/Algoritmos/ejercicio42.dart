import 'dart:io';

void main() {
  print('Coloque la edad (en meses o años según corresponda):');
  int datoEdad = int.parse(stdin.readLineSync()!);

  print('Ingrese género (H o M):');
  String datoGenero = stdin.readLineSync()!;

  print('Escriba el nivel de hemoglobina:');
  double datoHemo = double.parse(stdin.readLineSync()!);

  String veredicto = evaluarHemoglobina(datoEdad, datoGenero, datoHemo);

  print('Diagnóstico final: $veredicto');
}

String evaluarHemoglobina(int edadRef, String generoRef, double hemoRef) {
  double limiteBajo, limiteAlto;

  if (edadRef <= 2) {
    limiteBajo = 14; 
    limiteAlto = 27;
  } else if (edadRef <= 7) {
    limiteBajo = 11; 
    limiteAlto = 19;
  } else if (edadRef <= 13) {
    limiteBajo = 12; 
    limiteAlto = 16;
  } else if (edadRef <= 6) {
    limiteBajo = 12.5; 
    limiteAlto = 16;
  } else if (edadRef <= 11) {
    limiteBajo = 13.6; 
    limiteAlto = 16.4;
  } else if (edadRef <= 16) {
    limiteBajo = 14; 
    limiteAlto = 16.6;
  } else {
    if (generoRef == 'M') {
      limiteBajo = 13; 
      limiteAlto = 17;
    } else {
      limiteBajo = 15; 
      limiteAlto = 19;
    }
  }

  return hemoRef < limiteBajo ? 'Positivo para anemia' : 'Hemoglobina normal';
}
