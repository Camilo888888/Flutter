// Ejercicio 34: Incremento salarial por nivel según tabla modificada.
// Comentario: Se solicita nivel y salario, luego se aplica el aumento correspondiente.
import 'dart:io';

void main() {
  print('Ingrese nivel (ej: X, Y, Z):');
  String nivel = stdin.readLineSync()!;

  print('Ingrese salario actual:');
  double salarioBase = double.parse(stdin.readLineSync()!);

  double salarioAjustado = salarioBase;

  // Nueva tabla de aumentos por niveles
  if (nivel.toUpperCase() == 'X') {
    salarioAjustado = salarioBase * 1.12;   // 12%
  } else if (nivel.toUpperCase() == 'Y') {
    salarioAjustado = salarioBase * 1.08;   // 8%
  } else if (nivel.toUpperCase() == 'Z') {
    salarioAjustado = salarioBase * 1.04;   // 4%
  }

  print(
    'El resultado es: Nivel nuevo=$nivel, Salario actualizado=$salarioAjustado'
  );
}
