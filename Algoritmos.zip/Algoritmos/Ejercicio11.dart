// Ejercicio 11: Calcular salario considerando horas normales, horas extra y deducciones/asignaciones.
// Comentario: No se usan vectores. Se aplican porcentajes de deducción y asignaciones fijas.
import 'dart:io';

void main() {
  print('Digite el nombre del empleado:');
  String identificador = stdin.readLineSync()!;

  print('Digite la cantidad de horas regulares trabajadas:');
  double horasReg = double.parse(stdin.readLineSync()!);

  print('Digite el valor por cada hora regular:');
  double tarifaBase = double.parse(stdin.readLineSync()!);

  print('Digite la cantidad de horas adicionales trabajadas:');
  double horasAdicionales = double.parse(stdin.readLineSync()!);

  // Pago extra modificado (antes 1.25 → ahora 1.30)
  double tarifaExtra = tarifaBase * 1.30;
  double totalBase = horasReg * tarifaBase;
  double totalExtras = horasAdicionales * tarifaExtra;

  // Asignaciones modificadas
  double bonosAsignados = 28000 + (15000 * 1) + 19500;

  // Deducciones modificadas (antes 0.05+0.02+0.07=0.14 → ahora 0.06+0.03+0.05=0.14 también pero diferente distribución)
  double recargos = totalBase * (0.06 + 0.03 + 0.05);

  double totalFinal = totalBase + totalExtras + bonosAsignados - recargos;

  print('El total neto a recibir es: $totalFinal');
}
