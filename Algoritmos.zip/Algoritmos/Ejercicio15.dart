// Ejercicio 15: Monto total a pagar en un mes de luz eléctrica.
// Comentario: Se piden lecturas anterior y actual y costo por kW.
import 'dart:io';

void main() {
  print('Digite la lectura previa del contador:');
  double marcaPrev = double.parse(stdin.readLineSync()!);

  print('Digite la lectura nueva del contador:');
  double marcaNueva = double.parse(stdin.readLineSync()!);

  print('Digite el valor por cada kilovatio consumido:');
  double precioKw = double.parse(stdin.readLineSync()!);

  double usoEnergia = marcaNueva - marcaPrev;
  double montoFinal = usoEnergia * precioKw;

  print('El total a cancelar es: $montoFinal');
}
