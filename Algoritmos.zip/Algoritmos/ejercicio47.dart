void main() {
  mostrarNumeros();
}

void mostrarNumeros() {
  for (int numero = 1; numero < 100; numero += 2) {
    if (numero % 7 != 0) {
      print(numero);
    }
  }
}
