// Ejercicio 14: Resolver sistema de ecuaciones lineales aX + bY = c y dX + eY = f.
// Comentario: Se usan fórmulas directas (regla de Cramer).
void main() {
  double v1 = 4, v2 = 5, v3 = 22;
  double v4 = 3, v5 = -2, v6 = 4;

  double divisor = (v1 * v5 - v2 * v4);

  if (divisor == 0) {
    print('No existe una solución única para este sistema.');
    return;
  }

  double solX = (v3 * v5 - v2 * v6) / divisor;
  double solY = (v1 * v6 - v3 * v4) / divisor;

  print('Soluciones: X=$solX, Y=$solY');
}

