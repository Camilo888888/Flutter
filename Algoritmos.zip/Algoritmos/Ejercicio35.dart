// Ejercicio 35: Sugerir actividad física según grados Fahrenheit.
// Comentario: Se captura la temperatura y se determina la actividad recomendada.
import 'dart:io';

void main() {
  print('Ingrese grados Fahrenheit actuales:');
  double gradosF = double.parse(stdin.readLineSync()!);
  String actividad = '';

  if (gradosF < 45) {
    actividad = 'Entrenamiento en gimnasio';
  } else if (gradosF <= 65) {
    actividad = 'Caminata rápida';
  } else if (gradosF <= 90) {
    actividad = 'Ciclismo';
  } else {
    actividad = 'Béisbol recreativo';
  }

  print('El resultado es: Actividad sugerida = $actividad');
}

