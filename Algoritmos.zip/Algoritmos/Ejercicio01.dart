// Ejercicio 1: Obtener el promedio de edad de tres personas.
void main() {
  // Se asignan tres edades directamente
  int datoUno = 18;
  int datoDos = 27;
  int datoTres = 33;

  // Se calcula el promedio sumando las tres y dividiendo entre 3
  double promedioFinal = (datoUno + datoDos + datoTres) / 3;

  // Se muestra el resultado
  print('El promedio de edad es: $promedioFinal');
}
