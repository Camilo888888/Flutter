import 'dart:io';

void main() {
  print('Digite el valor estimado de la garantía hipotecaria:');
  double valorGarantia = double.parse(stdin.readLineSync()!);

  print('Digite el costo total del proyecto:');
  double costoProyecto = double.parse(stdin.readLineSync()!);

  Map<String, double> resultadoFinal =
      distribuirFondos(valorGarantia, costoProyecto);

  print(
      'Aporte personal: ${resultadoFinal['Personal']}, Aporte del aliado: ${resultadoFinal['Aliado']}');
}

Map<String, double> distribuirFondos(double valorHipoteca, double totalRequerido) {
  double aportePropio, aporteSocio;

  if (valorHipoteca < 1500000) {
    aportePropio = totalRequerido * 0.45;
    aporteSocio = totalRequerido * 0.55;
  } else {
    aportePropio = valorHipoteca;
    double dineroFaltante = totalRequerido - valorHipoteca;

    aporteSocio = dineroFaltante / 2;
    aportePropio += dineroFaltante / 2;
  }

  return {
    'Personal': aportePropio,
    'Aliado': aporteSocio
  };
}
