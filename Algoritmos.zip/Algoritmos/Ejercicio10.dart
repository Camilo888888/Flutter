// Ejercicio 10: Conversión de divisas entre chelines, dracmas, francos, dólares y liras.
void main() {
  // Se asignan valores iniciales de ejemplo
  double monedaA = 175; 
  double monedaB = 240; 
  double monedaC = 6200;

  // Se hacen las conversiones con nuevas tasas
  double valorPesetasA = monedaA * (912.450 / 100);
  double valorFrancosB = (monedaB * (79.330 / 100)) / 18.750;
  double valorDolaresC = monedaC / 134.880;
  double valorLirasC = (monedaC * 100) / 8.920;

  // Se muestran los resultados
  print('El equivalente de $monedaA chelines en pesetas es: $valorPesetasA');
  print('El equivalente de $monedaB dracmas en francos es: $valorFrancosB');
  print('El equivalente de $monedaC pesetas en dólares es: $valorDolaresC');
  print('El equivalente de $monedaC pesetas en liras es: $valorLirasC');
}
