// Ejercicio 27: Identificar figura según coincidencia entre áreas y un valor comparativo.
// Comentario: Se ingresan tres números y se comparan con las áreas calculadas.
import 'dart:io';
import 'dart:math';

void main() {
  print('Ingrese DatoA:');
  double datoA = double.parse(stdin.readLineSync()!);
  print('Ingrese DatoB:');
  double datoB = double.parse(stdin.readLineSync()!);
  print('Ingrese DatoC:');
  double datoC = double.parse(stdin.readLineSync()!);

  // Triángulo: (base * altura) / 2
  double areaTriangulo = (datoA * datoB) / 2;

  // Círculo: pi * r^2 (se usa datoA como radio y datoB como π)
  double areaCirculo = datoB * pow(datoA, 2);

  // Rectángulo: base * altura
  double areaRectangulo = datoA * datoB;

  if ((areaTriangulo - datoC).abs() < 1e-6) {
    print('El resultado es: Triángulo');
  } else if ((areaCirculo - datoC).abs() < 1e-6) {
    print('El resultado es: Círculo');
  } else if ((areaRectangulo - datoC).abs() < 1e-6) {
    print('El resultado es: Rectángulo');
  } else {
    print('El resultado es: Ninguna figura coincide con DatoC');
  }
}

