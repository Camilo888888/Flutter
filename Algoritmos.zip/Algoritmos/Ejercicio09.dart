
// Ejercicio 9: Calcular el salario neto con descuento del 20%.
import 'dart:io'; // Se importa para leer datos del teclado

void main() {
  // Se piden los datos al usuario
  print('Digite la cantidad total de horas trabajadas:');
  double totalHoras = double.parse(stdin.readLineSync()!);

  print('Digite el valor recibido por cada hora trabajada:');
  double valorUnidad = double.parse(stdin.readLineSync()!);

  // Se calculan salario bruto, descuento y neto (descuento cambiado a 22%)
  double montoBruto = totalHoras * valorUnidad;
  double rebaja = montoBruto * 0.22;
  double montoNeto = montoBruto - rebaja;

  // Se muestra el resultado
  print('El pago final después de descuentos es: $montoNeto');
}
