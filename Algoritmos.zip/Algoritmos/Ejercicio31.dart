// Ejercicio 31: Cálculo del costo por alquiler de vehículo según distancia recorrida.
// Comentario: Se ingresa kilómetros y se aplican tarifas por rangos.
import 'dart:io';

void main() {
  print('Ingrese distancia en kilómetros:');
  double distancia = double.parse(stdin.readLineSync()!);
  double montoFinal = 0;

  if (distancia <= 250) {
    montoFinal = 4800;
  } else if (distancia <= 900) {
    montoFinal = 4800 + (distancia - 250) * 220;
  } else {
    montoFinal = 4800 + (650) * 220 + (distancia - 900) * 160;
  }

  print('El resultado es: Total a pagar = $montoFinal');
}
