import 'dart:io';

void main() {
  print('Digite valor X:');
  int valorX = int.parse(stdin.readLineSync()!);

  print('Digite valor Y:');
  int valorY = int.parse(stdin.readLineSync()!);

  mostrarCuentaRegresiva(valorX, valorY);
}

void mostrarCuentaRegresiva(int limiteA, int limiteB) {
  for (int contador = limiteA; contador >= limiteB + 1; contador--) {
    print(contador);
  }
}
