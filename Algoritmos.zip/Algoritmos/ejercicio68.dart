// Ejercicio 68: Números perfectos
// Un número se dice que es perfecto si la suma de sus divisores excepto él mismo es igual a dicho
// número. Ejemplo: 6 es un número perfecto ya que sus divisores: 1 + 2 + 3 suman seis. Diseñe un
// algoritmo o programa que imprima los tres primeros números perfectos.

void main() {
  int count = 0;
  int num = 1;
  while (count < 3) {
    if (esPerfecto(num)) {
      print(num);
      count++;
    }
    num++;
  }
}

bool esPerfecto(int n) {
  int suma = 0;
  for (int i = 1; i < n; i++) {
    if (n % i == 0) suma += i;
  }
  return suma == n;
}
