// Ejercicio 70: Estadísticas de temperaturas
// Una estación climática proporciona un par de temperaturas diarias (máx, min), el rango normal de
// temperatura es entre 14 y 30 ° C. La pareja fin de temperaturas es 0,0. Se pide determinar:
// g. El número de días cuyas temperaturas se han proporcionado.
// h. Las medias máxima y mínima.
// i. Número de errores que ingresaron (temperaturas fuera de rango).
// j. Porcentaje que representan los errores ingresados.

import 'dart:io';

void main() {
  List<double> maxTemps = [];
  List<double> minTemps = [];
  int errores = 0;

  while (true) {
    print('Ingrese temperatura máxima y mínima (separadas por espacio, 0 0 para terminar):');
    String input = stdin.readLineSync()!;
    List<String> parts = input.split(' ');
    double max = double.parse(parts[0]);
    double min = double.parse(parts[1]);
    if (max == 0 && min == 0) break;
    maxTemps.add(max);
    minTemps.add(min);
    if (max < 14 || max > 30 || min < 14 || min > 30) errores++;
  }

  int dias = maxTemps.length;
  double mediaMax = maxTemps.reduce((a, b) => a + b) / dias;
  double mediaMin = minTemps.reduce((a, b) => a + b) / dias;
  double porcentajeErrores = (errores / dias) * 100;

  print('Número de días: $dias');
  print('Media máxima: ${mediaMax.toStringAsFixed(2)}');
  print('Media mínima: ${mediaMin.toStringAsFixed(2)}');
  print('Número de errores: $errores');
  print('Porcentaje de errores: ${porcentajeErrores.toStringAsFixed(2)}%');
}
