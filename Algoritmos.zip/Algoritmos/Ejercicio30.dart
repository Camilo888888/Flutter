// Ejercicio 30: Redondear número X formado por W, Y, Z, T a la centena más cercana.
// Comentario: Se arma X a partir de 4 dígitos ingresados.
import 'dart:io';
import 'dart:math';

void main() {
  print('Ingrese W:');
  int W = int.parse(stdin.readLineSync()!);
  print('Ingrese Y:');
  int Y = int.parse(stdin.readLineSync()!);
  print('Ingrese Z:');
  int Z = int.parse(stdin.readLineSync()!);
  print('Ingrese T:');
  int T = int.parse(stdin.readLineSync()!);

  int X = W * 1000 + Y * 100 + Z * 10 + T;
  int redondeo = (X / 100).round() * 100;

  print('El resultado es: X=$X, Redondeado=$redondeo');
}
