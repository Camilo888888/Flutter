import 'dart:io';

void main() {
  print('Ingrese valor inicial de Fahrenheit:');
  int fInicio = int.parse(stdin.readLineSync()!);

  print('Ingrese valor final de Fahrenheit:');
  int fFin = int.parse(stdin.readLineSync()!);

  print('Ingrese incremento:');
  int fPaso = int.parse(stdin.readLineSync()!);

  generarTablaTemperatura(fInicio, fFin, fPaso);
}

void generarTablaTemperatura(int fInicio, int fFin, int fPaso) {
  print('F\tC\tK\tR'); // encabezados

  for (int f = fInicio; f <= fFin; f += fPaso) {
    double c = 5 * (f - 32) / 9;
    double k = c + 273.15;
    double r = f + 459.67;

    print('$f\t${c.toStringAsFixed(2)}\t${k.toStringAsFixed(2)}\t${r.toStringAsFixed(2)}');
  }
}
