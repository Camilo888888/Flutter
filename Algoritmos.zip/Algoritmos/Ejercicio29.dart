// Ejercicio 29: Bonificación a áreas que superen el 33% de ventas globales.
// Comentario: Se usan 3 montos de ventas y un salario base referencial.
void main() {
  double ventaA = 45000, ventaB = 38000, ventaC = 22000;
  double totalVentas = ventaA + ventaB + ventaC;
  double salarioBase = 1200; // salario mensual de ejemplo

  double bonoA = (ventaA > totalVentas * 0.33) ? salarioBase * 0.20 : 0;
  double bonoB = (ventaB > totalVentas * 0.33) ? salarioBase * 0.20 : 0;
  double bonoC = (ventaC > totalVentas * 0.33) ? salarioBase * 0.20 : 0;

  print('El resultado es: BonoA=$bonoA, BonoB=$bonoB, BonoC=$bonoC');
}
