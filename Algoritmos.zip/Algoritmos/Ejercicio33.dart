// Ejercicio 33: Descuento según total de compra con tramos modificados.
// Comentario: Se solicita cliente y total; se aplican nuevos rangos y descuentos.
import 'dart:io';

void main() {
  print('Ingrese nombre del comprador:');
  String cliente = stdin.readLineSync()!;

  print('Ingrese total de la compra:');
  double total = double.parse(stdin.readLineSync()!);

  double rebaja = 0;

  if (total < 600) {
    rebaja = 0;
  } else if (total <= 1200) {
    rebaja = 0.06;     // 6%
  } else if (total <= 8000) {
    rebaja = 0.13;     // 13%
  } else if (total <= 16000) {
    rebaja = 0.20;     // 20%
  } else {
    rebaja = 0.28;     // 28%
  }

  double totalFinal = total * (1 - rebaja);

  print(
    'El resultado es: Comprador=$cliente, Total a pagar=$totalFinal, Descuento=${rebaja * 100}%.'
  );
}

