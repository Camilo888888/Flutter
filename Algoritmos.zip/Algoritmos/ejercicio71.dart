// Ejercicio 71: Estadísticas de orfanatorios
// La UNICEF desea obtener información estadística sobre los orfanatorios ubicados dentro de la
// República y sobre los niños huérfanos internados en esos orfanatorios. Por cada niño se conoce:
// sexo, edad, nombre del orfanatorio y estado de la República al que pertenece el Orfanatorio. Escriba
// un Programa para calcular y mostrar lo siguiente:
// a. Porcentaje de huérfanos del Estado Táchira y del Distrito Capital respecto al total del País.
// b. Número de huérfanos en cada grupo. Los grupos se definen según la Edad:
// Grupo 1: menores de 1 año
// Grupo 2: edad comprendida entre 1 y 3 años
// Grupo 3: edad comprendida entre 4 y 6 años
// Grupo 4: mayores de 6 años
// c. Cantidad de niños y niñas y porcentaje que representa cada uno.

import 'dart:io';

void main() {
  List<String> sexos = [];
  List<int> edades = [];
  List<String> orfanatorios = [];
  List<String> estados = [];

  print('Ingrese número de niños:');
  int n = int.parse(stdin.readLineSync()!);

  for (int i = 0; i < n; i++) {
    print('Niño ${i + 1}: sexo (M/F), edad, orfanatorio, estado:');
    List<String> input = stdin.readLineSync()!.split(' ');
    sexos.add(input[0]);
    edades.add(int.parse(input[1]));
    orfanatorios.add(input[2]);
    estados.add(input[3]);
  }

  int total = n;
  int tachira = estados.where((e) => e == 'Tachira').length;
  int capital = estados.where((e) => e == 'Capital').length;
  double pctTachira = (tachira / total) * 100;
  double pctCapital = (capital / total) * 100;

  int grupo1 = edades.where((e) => e < 1).length;
  int grupo2 = edades.where((e) => e >= 1 && e <= 3).length;
  int grupo3 = edades.where((e) => e >= 4 && e <= 6).length;
  int grupo4 = edades.where((e) => e > 6).length;

  int ninos = sexos.where((s) => s == 'M').length;
  int ninas = sexos.where((s) => s == 'F').length;
  double pctNinos = (ninos / total) * 100;
  double pctNinas = (ninas / total) * 100;

  print('Porcentaje Tachira: ${pctTachira.toStringAsFixed(2)}%');
  print('Porcentaje Capital: ${pctCapital.toStringAsFixed(2)}%');
  print('Grupo 1: $grupo1, Grupo 2: $grupo2, Grupo 3: $grupo3, Grupo 4: $grupo4');
  print('Niños: $ninos (${pctNinos.toStringAsFixed(2)}%), Niñas: $ninas (${pctNinas.toStringAsFixed(2)}%)');
}
