// Ejercicio 77: Estadísticas de estudiantes
// Se desea obtener estadísticas sobre los estudiantes de una universidad. Para cada estudiante se
// conoce: nombre, edad, sexo, carrera, promedio. Se pide calcular y mostrar:
// a. El estudiante con el mayor promedio (nombre y carrera).
// b. El estudiante con el menor promedio (nombre y carrera).
// c. El promedio de edad de los estudiantes.
// d. El porcentaje de estudiantes hombres y mujeres.
// e. La carrera con más estudiantes.
// f. El promedio general de los promedios de los estudiantes.

import 'dart:io';

void main() {
  print('Ingrese número de estudiantes:');
  int n = int.parse(stdin.readLineSync()!);

  List<String> nombres = [];
  List<int> edades = [];
  List<String> sexos = [];
  List<String> carreras = [];
  List<double> promedios = [];

  for (int i = 0; i < n; i++) {
    print('Estudiante ${i + 1}: nombre, edad, sexo (M/F), carrera, promedio:');
    List<String> input = stdin.readLineSync()!.split(' ');
    nombres.add(input[0]);
    edades.add(int.parse(input[1]));
    sexos.add(input[2]);
    carreras.add(input[3]);
    promedios.add(double.parse(input[4]));
  }

  double maxProm = promedios.reduce((a, b) => a > b ? a : b);
  double minProm = promedios.reduce((a, b) => a < b ? a : b);
  int idxMax = promedios.indexOf(maxProm);
  int idxMin = promedios.indexOf(minProm);

  double avgEdad = edades.reduce((a, b) => a + b) / n;
  int hombres = sexos.where((s) => s == 'M').length;
  int mujeres = sexos.where((s) => s == 'F').length;
  double pctHombres = (hombres / n) * 100;
  double pctMujeres = (mujeres / n) * 100;

  Map<String, int> carreraCount = {};
  for (String c in carreras) {
    carreraCount[c] = (carreraCount[c] ?? 0) + 1;
  }
  String maxCarrera = carreraCount.keys.reduce((a, b) => carreraCount[a]! > carreraCount[b]! ? a : b);

  double avgProm = promedios.reduce((a, b) => a + b) / n;

  print('Mayor promedio: ${nombres[idxMax]} ${carreras[idxMax]}');
  print('Menor promedio: ${nombres[idxMin]} ${carreras[idxMin]}');
  print('Promedio edad: ${avgEdad.toStringAsFixed(2)}');
  print('Porcentaje hombres: ${pctHombres.toStringAsFixed(2)}%, mujeres: ${pctMujeres.toStringAsFixed(2)}%');
  print('Carrera con más estudiantes: $maxCarrera');
  print('Promedio general: ${avgProm.toStringAsFixed(2)}');
}
