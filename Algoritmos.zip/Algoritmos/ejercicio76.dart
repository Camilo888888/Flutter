// Ejercicio 76: Estadísticas de ventas de productos
// Una empresa comercializa productos de limpieza. Se desea obtener estadísticas de ventas de
// productos. Para cada producto se conoce: código, nombre, precio de venta, cantidad vendida.
// Se pide calcular y mostrar:
// a. El producto más vendido (código y nombre).
// b. El producto menos vendido (código y nombre).
// c. El producto que generó más ingresos (código y nombre).
// d. El producto que generó menos ingresos (código y nombre).
// e. El promedio de ingresos generados por los productos.
// f. El porcentaje de productos que vendieron más de 100 unidades.

import 'dart:io';

void main() {
  print('Ingrese número de productos:');
  int n = int.parse(stdin.readLineSync()!);

  List<String> codigos = [];
  List<String> nombres = [];
  List<double> precios = [];
  List<int> cantidades = [];
  List<double> ingresos = [];

  for (int i = 0; i < n; i++) {
    print('Producto ${i + 1}: código, nombre, precio, cantidad:');
    List<String> input = stdin.readLineSync()!.split(' ');
    codigos.add(input[0]);
    nombres.add(input[1]);
    precios.add(double.parse(input[2]));
    cantidades.add(int.parse(input[3]));
    ingresos.add(precios[i] * cantidades[i]);
  }

  int maxCant = cantidades.reduce((a, b) => a > b ? a : b);
  int minCant = cantidades.reduce((a, b) => a < b ? a : b);
  double maxIng = ingresos.reduce((a, b) => a > b ? a : b);
  double minIng = ingresos.reduce((a, b) => a < b ? a : b);
  double avgIng = ingresos.reduce((a, b) => a + b) / n;
  int mas100 = cantidades.where((c) => c > 100).length;
  double pctMas100 = (mas100 / n) * 100;

  int idxMaxCant = cantidades.indexOf(maxCant);
  int idxMinCant = cantidades.indexOf(minCant);
  int idxMaxIng = ingresos.indexOf(maxIng);
  int idxMinIng = ingresos.indexOf(minIng);

  print('Más vendido: ${codigos[idxMaxCant]} ${nombres[idxMaxCant]}');
  print('Menos vendido: ${codigos[idxMinCant]} ${nombres[idxMinCant]}');
  print('Más ingresos: ${codigos[idxMaxIng]} ${nombres[idxMaxIng]}');
  print('Menos ingresos: ${codigos[idxMinIng]} ${nombres[idxMinIng]}');
  print('Promedio ingresos: ${avgIng.toStringAsFixed(2)}');
  print('Porcentaje >100 unidades: ${pctMas100.toStringAsFixed(2)}%');
}
