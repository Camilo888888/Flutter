import 'dart:io';

void main() {
  print('Digite el monto disponible actualmente:');
  double fondoBase = double.parse(stdin.readLineSync()!);

  Map<String, double> datosSalida = organizarPresupuesto(fondoBase);

  print(
      'Crédito solicitado: ${datosSalida['Credito']}, Materiales: ${datosSalida['Materiales']}, Bonificaciones: ${datosSalida['Bonos']}');
}

Map<String, double> organizarPresupuesto(double montoInicial) {
  double montoCredito = 0;

  if (montoInicial < 0) {
    montoCredito = 12000 - montoInicial;
    montoInicial = 12000;
  } else if (montoInicial > 0 && montoInicial < 25000) {
    montoCredito = 25000 - montoInicial;
    montoInicial = 25000;
  }

  double valorTecnologia = 6000;
  double valorMuebles = 3000;

  double sobrante = montoInicial - valorTecnologia - valorMuebles;

  double valorMateriales = sobrante / 2;
  double valorBonificaciones = sobrante / 2;

  return {
    'Credito': montoCredito,
    'Materiales': valorMateriales,
    'Bonos': valorBonificaciones
  };
}
