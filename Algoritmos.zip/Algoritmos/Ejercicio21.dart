// Ejercicio 21: Calcular el porcentaje de utilidad en la venta de frutas.
// Comentario: Se usan valores modificados para las pruebas.
void main() {
  double totalFrutas = 52000; // cantidad de frutas compradas
  double precioDocena = 8;    // precio por docena
  double ingresoVenta = 45000; // dinero recibido por la venta

  // Costo total de adquisición: (totalFrutas / 12) * precioDocena
  double costoFinal = (totalFrutas / 12) * precioDocena;
  double porcentajeUtilidad = ((ingresoVenta - costoFinal) / costoFinal) * 100;

  print('El resultado es: Utilidad = $porcentajeUtilidad%');
}
