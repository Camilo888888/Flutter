// Ejercicio 38: A partir de una fecha de nacimiento, determinar constelación zodiacal y cálculo de años.
// Comentario: Se usan rangos mes-día y un año base diferente.

import 'dart:io';

void main() {
  print('Ingrese número de día (1-31):');
  int diaN = int.parse(stdin.readLineSync()!);

  print('Ingrese número de mes (1-12):');
  int mesN = int.parse(stdin.readLineSync()!);

  print('Ingrese año en que nació:');
  int anioN = int.parse(stdin.readLineSync()!);

  // Año de referencia cambiado
  int añosVividos = 2030 - anioN;

  String constel = '';

  if ((mesN == 3 && diaN >= 18) || (mesN == 4 && diaN <= 17)) constel = 'Arión';
  else if ((mesN == 4 && diaN >= 18) || (mesN == 5 && diaN <= 18)) constel = 'Taurix';
  else if ((mesN == 5 && diaN >= 19) || (mesN == 6 && diaN <= 19)) constel = 'Gémina';
  else if ((mesN == 6 && diaN >= 20) || (mesN == 7 && diaN <= 21)) constel = 'Cánthor';
  else if ((mesN == 7 && diaN >= 22) || (mesN == 8 && diaN <= 21)) constel = 'Leonar';
  else if ((mesN == 8 && diaN >= 22) || (mesN == 9 && diaN <= 21)) constel = 'Virnix';
  else if ((mesN == 9 && diaN >= 22) || (mesN == 10 && diaN <= 21)) constel = 'Libral';
  else if ((mesN == 10 && diaN >= 22) || (mesN == 11 && diaN <= 20)) constel = 'Escórnix';
  else if ((mesN == 11 && diaN >= 21) || (mesN == 12 && diaN <= 20)) constel = 'Sagiril';
  else if ((mesN == 12 && diaN >= 21) || (mesN == 1 && diaN <= 18)) constel = 'Caprion';
  else if ((mesN == 1 && diaN >= 19) || (mesN == 2 && diaN <= 17)) constel = 'Acuárion';
  else constel = 'Piscari';

  print('El resultado es: Constelación=$constel, Años vividos=$añosVividos');
}
