
// Ejercicio 8: Calcular el área de un triángulo con la fórmula de Herón.
import 'dart:math'; // Se importa para usar funciones matemáticas

void main() {
  // Se asignan los tres lados del triángulo
  double ladoX = 8, ladoY = 9, ladoZ = 10;

  // Se calcula el semiperímetro
  double semiPeri = (ladoX + ladoY + ladoZ) / 2;

  // Se aplica la fórmula de Herón
  double resultadoArea = sqrt(
      semiPeri *
      (semiPeri - ladoX) *
      (semiPeri - ladoY) *
      (semiPeri - ladoZ)
  );

  // Se muestra el área
  print('El área del triángulo es: $resultadoArea');
}
