// Ejercicio 69: Números amigos
// Dos números A y B son amigos, cuando la suma de los divisores menores que A es igual a B, al mismo
// tiempo cuando la suma de los divisores menores que B es igual a A. Los dos menores números amigos
// son 220 y 284. Diseñe un algoritmo o programa que imprima los tres primeros pares de números amigos.

void main() {
  int count = 0;
  int a = 1;
  while (count < 3) {
    int b = sumaDivisores(a);
    if (b > a && sumaDivisores(b) == a) {
      print('$a y $b');
      count++;
    }
    a++;
  }
}

int sumaDivisores(int n) {
  int suma = 0;
  for (int i = 1; i < n; i++) {
    if (n % i == 0) suma += i;
  }
  return suma;
}
