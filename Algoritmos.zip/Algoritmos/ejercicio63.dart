// Ejercicio 63: Estadísticas de encuesta de alumnos
// En una encuesta de alumnos se tomaron los siguientes datos: edad, sexo, estado civil, y especialidad
// que cursa. La empresa encuestadora, desea generar las siguientes estadísticas:
// a. Promedio de edad de las mujeres.
// b. Promedio de edad de los hombres.
// c. Cantidad de hombres y de mujeres encuestados.
// d. Porcentaje de personas para cada uno de los tipos de estado civil, respecto al total.
// e. Cantidad de alumnos por especialidad y porcentaje que representan.
// f. Porcentaje de mujeres adultas, tomando en cuenta que los adultos son los que tienen más de 21 años.
// g. Porcentaje de hombres jóvenes, tomando en cuenta que estos son los que tienen menos de 21 años, pero más de 17.
// h. Cantidad de hombres solteros y cantidad de mujeres solteras.

import 'dart:io';

void main() {
  print('Ingrese el número de alumnos encuestados:');
  int n = int.parse(stdin.readLineSync()!);

  List<int> edades = [];
  List<String> sexos = [];
  List<String> estadosCiviles = [];
  List<String> especialidades = [];

  for (int i = 0; i < n; i++) {
    print('Alumno ${i + 1}:');
    print('Edad:');
    edades.add(int.parse(stdin.readLineSync()!));
    print('Sexo (M/F):');
    sexos.add(stdin.readLineSync()!.toUpperCase());
    print('Estado civil (S/C/D/V):'); // S=soltero, C=casado, D=divorciado, V=viudo
    estadosCiviles.add(stdin.readLineSync()!.toUpperCase());
    print('Especialidad:');
    especialidades.add(stdin.readLineSync()!);
  }

  // a. Promedio de edad de las mujeres
  List<int> edadesMujeres = [];
  for (int i = 0; i < n; i++) {
    if (sexos[i] == 'F') edadesMujeres.add(edades[i]);
  }
  double promedioMujeres = edadesMujeres.isNotEmpty ? edadesMujeres.reduce((a, b) => a + b) / edadesMujeres.length : 0;
  print('Promedio de edad de las mujeres: ${promedioMujeres.toStringAsFixed(2)}');

  // b. Promedio de edad de los hombres
  List<int> edadesHombres = [];
  for (int i = 0; i < n; i++) {
    if (sexos[i] == 'M') edadesHombres.add(edades[i]);
  }
  double promedioHombres = edadesHombres.isNotEmpty ? edadesHombres.reduce((a, b) => a + b) / edadesHombres.length : 0;
  print('Promedio de edad de los hombres: ${promedioHombres.toStringAsFixed(2)}');

  // c. Cantidad de hombres y mujeres
  int hombres = sexos.where((s) => s == 'M').length;
  int mujeres = sexos.where((s) => s == 'F').length;
  print('Cantidad de hombres: $hombres');
  print('Cantidad de mujeres: $mujeres');

  // d. Porcentaje por estado civil
  Map<String, int> conteoEstados = {};
  for (String ec in estadosCiviles) {
    conteoEstados[ec] = (conteoEstados[ec] ?? 0) + 1;
  }
  conteoEstados.forEach((ec, count) {
    double porcentaje = (count / n) * 100;
    print('Porcentaje de $ec: ${porcentaje.toStringAsFixed(2)}%');
  });

  // e. Cantidad por especialidad y porcentaje
  Map<String, int> conteoEspecialidades = {};
  for (String esp in especialidades) {
    conteoEspecialidades[esp] = (conteoEspecialidades[esp] ?? 0) + 1;
  }
  conteoEspecialidades.forEach((esp, count) {
    double porcentaje = (count / n) * 100;
    print('Especialidad $esp: $count alumnos (${porcentaje.toStringAsFixed(2)}%)');
  });

  // f. Porcentaje de mujeres adultas (>21 años)
  int mujeresAdultas = 0;
  for (int i = 0; i < n; i++) {
    if (sexos[i] == 'F' && edades[i] > 21) mujeresAdultas++;
  }
  double porcentajeMujeresAdultas = mujeres > 0 ? (mujeresAdultas / mujeres) * 100 : 0;
  print('Porcentaje de mujeres adultas: ${porcentajeMujeresAdultas.toStringAsFixed(2)}%');

  // g. Porcentaje de hombres jóvenes (17 < edad < 21)
  int hombresJovenes = 0;
  for (int i = 0; i < n; i++) {
    if (sexos[i] == 'M' && edades[i] > 17 && edades[i] < 21) hombresJovenes++;
  }
  double porcentajeHombresJovenes = hombres > 0 ? (hombresJovenes / hombres) * 100 : 0;
  print('Porcentaje de hombres jóvenes: ${porcentajeHombresJovenes.toStringAsFixed(2)}%');

  // h. Cantidad de hombres solteros y mujeres solteras
  int hombresSolteros = 0;
  int mujeresSolteras = 0;
  for (int i = 0; i < n; i++) {
    if (sexos[i] == 'M' && estadosCiviles[i] == 'S') hombresSolteros++;
    if (sexos[i] == 'F' && estadosCiviles[i] == 'S') mujeresSolteras++;
  }
  print('Hombres solteros: $hombresSolteros');
  print('Mujeres solteras: $mujeresSolteras');
}
