// Ejercicio 32: Verificar si R y S cumplen R^3 + S^4 – 2*R^2 > 750.
// Comentario: Se solicitan R y S desde el teclado.
import 'dart:io';
import 'dart:math';

void main() {
  print('Ingrese R:');
  double R = double.parse(stdin.readLineSync()!);
  print('Ingrese S:');
  double S = double.parse(stdin.readLineSync()!);

  double resultado = pow(R, 3) + pow(S, 4) - 2 * pow(R, 2);

  if (resultado > 750) {
    print('El resultado es: R=$R, S=$S cumplen la condición (valor=$resultado)');
  } else {
    print('El resultado es: No cumplen la condición (valor=$resultado)');
  }
}
