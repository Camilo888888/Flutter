// Ejercicio 40: Determinar valor total por energía consumida y cargo adicional de limpieza.
// Comentario: Se ingresan mediciones y se aplica tarifa según rangos.

import 'dart:io';

void main() {
  print('Digite lectura previa:');
  double lecturaPrev = double.parse(stdin.readLineSync()!);

  print('Digite lectura reciente:');
  double lecturaNow = double.parse(stdin.readLineSync()!);

  double uso = lecturaNow - lecturaPrev;
  double tarifa;

  if (uso <= 120) {
    tarifa = 2450.00;
  } else if (uso <= 280) {
    tarifa = 83.40;
  } else if (uso <= 480) {
    tarifa = 91.10;
  } else {
    tarifa = 105.75;
  }

  double valorEnergia = uso * tarifa;
  double cargoLimpieza = 8500; // monto fijo renovado
  double totalPagar = valorEnergia + cargoLimpieza;

  print('Resultado final → Energía=$valorEnergia, Limpieza=$cargoLimpieza, Total=$totalPagar');
}

