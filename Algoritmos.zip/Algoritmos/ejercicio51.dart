// 51. Calcular el término doceavo y la suma de los doce primeros términos de la sucesión: 6, 11, 16, 21.
// Respuesta: a12=61, suma=402

/// Clase para manejar la sucesión aritmética
class SucesionAritmetica {
  // Propiedades privadas
  final int primerTermino;
  final int diferencia;

  /// Constructor que permite inicializar la sucesión
  SucesionAritmetica({this.primerTermino = 6, this.diferencia = 5});

  /// Método para calcular el término n-ésimo
  int calcularTermino(int n) {
    return primerTermino + (n - 1) * diferencia;
  }

  /// Método para calcular la suma de los primeros n términos
  int calcularSuma(int n) {
    return n * (2 * primerTermino + (n - 1) * diferencia) ~/ 2;
  }

  /// Método para obtener resultados formateados
  String obtenerResultados(int n) {
    int terminoN = calcularTermino(n);
    int sumaN = calcularSuma(n);
    return 'Término $n: $terminoN, Suma de $n términos: $sumaN';
  }
}

void main() {
  final SucesionAritmetica sucesion = SucesionAritmetica();
  print('--- Ejercicio 51: Sucesión Aritmética ---');
  print(sucesion.obtenerResultados(12));
}
