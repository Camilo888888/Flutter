// Ejercicio 6: Calcular el porcentaje de hombres y mujeres en un grupo.
void main() {
  // Se asigna la cantidad de hombres y mujeres
  int grupoA = 15;
  int grupoB = 10;
  int totalPersonas = grupoA + grupoB;

  // Se calculan los porcentajes
  double porcentajeA = (grupoA * 100) / totalPersonas;
  double porcentajeB = (grupoB * 100) / totalPersonas;

  // Se muestran los resultados
  print('Porcentaje del grupo A: $porcentajeA%');
  print('Porcentaje del grupo B: $porcentajeB%');
}

