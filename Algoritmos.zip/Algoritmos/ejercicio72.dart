// Ejercicio 72: Fuerza de atracción gravitacional
// Conociendo la masa y distancia de dos cuerpos se puede determinar la Fuerza de atracción que se
// ejerce entre ambos. Se desea determinar las fuerzas de atracción ejercida entre la tierra y diversos
// satélites ubicados a distintas alturas. Para lo cual la NASA le ha solicitado a usted construir un
// programa que responda a los siguientes requerimientos:
// a) Cuál es la mayor y menor fuerza de atracción ejercida por los satélites en estudio
// b) La fuerza de atracción promedio ejercida por los satélites en estudio
// c) La mayor masa de todos los satélites estudiados
// d) La masa promedio de los satélites
// e) La menor y mayor altura de los satélites
// La fórmula para determinar la Fuerza de atracción es:
// F = G m M / r^2
// donde:
// m: masa satélite;
// M: Masa tierra (5,97 * 10^24 Kg);
// r: distancia de los cuerpos;
// G: Constante Gravitatoria (6,67259 * 10^-11 N*m^2 / Kg^2)
// Considere la siguiente muestra para realizar la prueba del Programa:
// Satélite País Masa Altura
// Kg. Mts
// Canada 1 Canadá 8.300 31.200.000
// Alfa 1 Chile 5.500 36.000.000
// Boby 4 EE.UU. 12.000 33.450.000
// Che 3 Argentina 3.350 34.200.000

import 'dart:io';
import 'dart:math';

void main() {
  double G = 6.67259e-11;
  double M = 5.97e24;

  List<String> paises = ['Canadá', 'Chile', 'EE.UU.', 'Argentina'];
  List<double> masas = [8300, 5500, 12000, 3350];
  List<double> alturas = [31200000, 36000000, 33450000, 34200000];

  List<double> fuerzas = [];
  for (int i = 0; i < masas.length; i++) {
    double r = alturas[i] + 6371000; // Radio tierra aproximado
    double F = G * masas[i] * M / pow(r, 2);
    fuerzas.add(F);
  }

  double maxF = fuerzas.reduce(max);
  double minF = fuerzas.reduce(min);
  double avgF = fuerzas.reduce((a, b) => a + b) / fuerzas.length;

  double maxMasa = masas.reduce(max);
  double avgMasa = masas.reduce((a, b) => a + b) / masas.length;

  double minAlt = alturas.reduce(min);
  double maxAlt = alturas.reduce(max);

  print('Mayor fuerza: ${maxF.toStringAsFixed(2)} N');
  print('Menor fuerza: ${minF.toStringAsFixed(2)} N');
  print('Fuerza promedio: ${avgF.toStringAsFixed(2)} N');
  print('Mayor masa: ${maxMasa.toStringAsFixed(2)} Kg');
  print('Masa promedio: ${avgMasa.toStringAsFixed(2)} Kg');
  print('Menor altura: ${minAlt.toStringAsFixed(2)} m');
  print('Mayor altura: ${maxAlt.toStringAsFixed(2)} m');
}
