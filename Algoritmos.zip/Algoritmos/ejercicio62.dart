// Ejercicio 62: Estadísticas de empresas
// Para cada una de las empresas del País se tienen como datos: actividad, localización y número de
// trabajadores. La actividad y la localización, se codifican de la siguiente forma:
// (Nota: El texto no especifica los códigos, así que asumiré códigos simples: actividad 1=agrícola, 2=minera, 3=industrial; localización 1=norte, 2=sur, 3=este, 4=oeste)
// Desarrolle un algoritmo / programa que calcule y muestre:
// i. Porcentaje de empresas agrícolas del País.
// ii. Porcentaje de empresas mineras del sur respecto al total de empresas que realizan esa actividad.
// iii. Promedio de trabajadores de las empresas de cada tipo de actividad.
// iv. Localización con mayor número de empresas industriales.

import 'dart:io';

void main() {
  print('Ingrese el número de empresas:');
  int n = int.parse(stdin.readLineSync()!);

  List<int> actividades = [];
  List<int> localizaciones = [];
  List<int> trabajadores = [];

  for (int i = 0; i < n; i++) {
    print('Empresa ${i + 1}:');
    print('Actividad (1=agrícola, 2=minera, 3=industrial):');
    actividades.add(int.parse(stdin.readLineSync()!));
    print('Localización (1=norte, 2=sur, 3=este, 4=oeste):');
    localizaciones.add(int.parse(stdin.readLineSync()!));
    print('Número de trabajadores:');
    trabajadores.add(int.parse(stdin.readLineSync()!));
  }

  // i. Porcentaje de empresas agrícolas
  int agricolas = actividades.where((a) => a == 1).length;
  double porcentajeAgricolas = (agricolas / n) * 100;
  print('Porcentaje de empresas agrícolas: ${porcentajeAgricolas.toStringAsFixed(2)}%');

  // ii. Porcentaje de empresas mineras del sur
  int mineras = actividades.where((a) => a == 2).length;
  int minerasSur = 0;
  for (int i = 0; i < n; i++) {
    if (actividades[i] == 2 && localizaciones[i] == 2) {
      minerasSur++;
    }
  }
  double porcentajeMinerasSur = mineras > 0 ? (minerasSur / mineras) * 100 : 0;
  print('Porcentaje de empresas mineras del sur: ${porcentajeMinerasSur.toStringAsFixed(2)}%');

  // iii. Promedio de trabajadores por actividad
  Map<int, List<int>> trabajadoresPorActividad = {};
  for (int i = 0; i < n; i++) {
    trabajadoresPorActividad.putIfAbsent(actividades[i], () => []).add(trabajadores[i]);
  }
  trabajadoresPorActividad.forEach((act, trab) {
    double promedio = trab.reduce((a, b) => a + b) / trab.length;
    String nombreAct = act == 1 ? 'agrícola' : act == 2 ? 'minera' : 'industrial';
    print('Promedio de trabajadores en $nombreAct: ${promedio.toStringAsFixed(2)}');
  });

  // iv. Localización con mayor número de empresas industriales
  Map<int, int> industrialesPorLoc = {};
  for (int i = 0; i < n; i++) {
    if (actividades[i] == 3) {
      industrialesPorLoc[localizaciones[i]] = (industrialesPorLoc[localizaciones[i]] ?? 0) + 1;
    }
  }
  if (industrialesPorLoc.isNotEmpty) {
    int maxLoc = industrialesPorLoc.keys.reduce((a, b) => industrialesPorLoc[a]! > industrialesPorLoc[b]! ? a : b);
    String nombreLoc = maxLoc == 1 ? 'norte' : maxLoc == 2 ? 'sur' : maxLoc == 3 ? 'este' : 'oeste';
    print('Localización con mayor número de empresas industriales: $nombreLoc');
  } else {
    print('No hay empresas industriales.');
  }
}
