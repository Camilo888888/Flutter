// Ejercicio 66: Cálculo de montos por equipaje en aerolínea
// Una aerolínea está interesada en diseñar un software que le permita calcular y acumular los montos
// a pagar por equipaje para cada uno de sus vuelos. El algoritmo debe procesar todos los vuelos del
// día con sus respectivos pasajeros y maletas, las cuales están identificadas por un código. Las tarifas
// por kilogramos se muestran en la siguiente tabla:
// PESOS TARIFA POR Kgs.
// 1 a 3 Kgs. 0
// 3.01 a 6 Kgs 600
// 6.01 a 9 Kgs 1200
// 9.01 a 12 Kgs 1500
// 12.01 a 15 Kgs 2000
// más de 15 Kgs. 2500
// Se quiere un algoritmo en seudocódigo o diagrama estructurado que permita:
// i. Imprimir por pasajero el número de vuelo, el código de abordo, el nombre, el total de kilogramos
// del equipaje con su respectivo monto a pagar.
// ii. Imprimir por pasajero el número de vuelo, el nombre y el código de la maleta con mayor peso.
// iii. Imprimir para cada vuelo el número de vuelo, el código de abordo, el nombre y el peso total
// para el pasajero con mayor y menor peso total del equipaje.
// iv. Imprimir para cada vuelo el número de vuelo y el monto total cancelado por equipaje.
// v. Imprimir el porcentaje de pasajeros que no pagaron por equipaje.
// NOTA: No se podrán utilizar vectores ni matrices.

// Este es un seudocódigo en Dart, pero sin usar listas para simular la restricción.

import 'dart:io';

void main() {
  // Simulación de datos (en un programa real, se leerían de entrada)
  // Vuelo 1: Pasajero 1: nombre, codigoAbordo, maletas: [peso1, peso2, ...]
  // Para simplicidad, asumir un vuelo con un pasajero.

  print('Ingrese número de vuelo:');
  int vuelo = int.parse(stdin.readLineSync()!);
  print('Ingrese código de abordo:');
  String codigoAbordo = stdin.readLineSync()!;
  print('Ingrese nombre del pasajero:');
  String nombre = stdin.readLineSync()!;
  print('Ingrese número de maletas:');
  int numMaletas = int.parse(stdin.readLineSync()!);

  double totalKg = 0;
  double monto = 0;
  double maxPeso = 0;
  String codigoMax = '';

  for (int i = 0; i < numMaletas; i++) {
    print('Maleta ${i + 1}: código y peso:');
    String codigo = stdin.readLineSync()!;
    double peso = double.parse(stdin.readLineSync()!);
    totalKg += peso;
    if (peso > maxPeso) {
      maxPeso = peso;
      codigoMax = codigo;
    }
    if (peso > 3) {
      if (peso <= 6) monto += 600;
      else if (peso <= 9) monto += 1200;
      else if (peso <= 12) monto += 1500;
      else if (peso <= 15) monto += 2000;
      else monto += 2500;
    }
  }

  // i. Imprimir por pasajero
  print('Vuelo: $vuelo, Código: $codigoAbordo, Nombre: $nombre, Total Kg: $totalKg, Monto: \$${monto.toStringAsFixed(2)}');

  // ii. Maleta con mayor peso
  print('Vuelo: $vuelo, Nombre: $nombre, Código maleta mayor peso: $codigoMax, Peso: $maxPeso');

  // iii. Para vuelo (simulado como único)
  print('Vuelo: $vuelo, Código: $codigoAbordo, Nombre: $nombre, Peso total: $totalKg (mayor/menor asumido)');

  // iv. Monto total por vuelo
  print('Vuelo: $vuelo, Monto total: \$${monto.toStringAsFixed(2)}');

  // v. Porcentaje sin pago (si monto == 0)
  double porcentajeSinPago = monto == 0 ? 100 : 0;
  print('Porcentaje de pasajeros sin pago: ${porcentajeSinPago.toStringAsFixed(2)}%');
}
