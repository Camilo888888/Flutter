// Ejercicio 41: Cálculo de árboles por tipo según extensión del área a reforestar.
// Comentario: Se usa la extensión en hectáreas y se determina el número de árboles por categoría.

import 'dart:io';

void main() {
  print('Digite la cantidad de hectáreas del terreno:');
  double hects = double.parse(stdin.readLineSync()!);

  Map<String, int> arboles = obtenerPlantas(hects);

  print('Cantidad de Abetos: ${arboles["Abetos"]},');
  print('Cantidad de Cipreses: ${arboles["Cipreses"]},');
  print('Cantidad de Nogales: ${arboles["Nogales"]}');
}

Map<String, int> obtenerPlantas(double hct) {
  double metrosTotales = hct * 10000;

  int abetos, cipreses, nogales;

  if (metrosTotales > 1000000) {
    // Área mayor al millón de m² → 70%-20%-10%
    abetos = ((metrosTotales * 0.70) / 10 * 8).toInt();   // 8 abetos por cada 10 m²
    cipreses = ((metrosTotales * 0.20) / 15 * 15).toInt(); // 15 cipreses por cada 15 m²
    nogales = ((metrosTotales * 0.10) / 18 * 10).toInt();  // 10 nogales por cada 18 m²
  } else {
    // Área menor o igual → 50%-30%-20%
    abetos = ((metrosTotales * 0.50) / 10 * 8).toInt();
    cipreses = ((metrosTotales * 0.30) / 15 * 15).toInt();
    nogales = ((metrosTotales * 0.20) / 18 * 10).toInt();
  }

  return {
    'Abetos': abetos,
    'Cipreses': cipreses,
    'Nogales': nogales,
  };
}
