// Ejercicio 24: Reinvertir rendimiento cuando supera cierto umbral.
// Comentario: Se pide monto inicial y se calcula rendimiento mensual modificado.
import 'dart:io';

void main() {
  print('Ingrese monto inicial invertido:');
  double montoBase = double.parse(stdin.readLineSync()!);
  double tasaMes = 0.015; // ejemplo 1.5%
  double rendimiento = montoBase * tasaMes;
  double limite = 8200; // nuevo umbral

  if (rendimiento > limite) {
    montoBase += rendimiento;
  }

  print('El resultado es: Monto final = $montoBase');
}
