// Ejercicio 16: Piezas fabricadas por lámina y desperdicio.
// Comentario: Se asignan medidas promedio y consumo por pieza.
void main() {
  double medidaLargo = 5.2;
  double medidaAncho = 1.8;

  double areaTotal = medidaLargo * medidaAncho; // metros cuadrados
  double usoUnidad = 0.6; // metros cuadrados por pieza

  int cantidadPiezas = (areaTotal / usoUnidad).floor();
  double restoMaterial = areaTotal - (cantidadPiezas * usoUnidad);

  print('Resultado: Piezas=$cantidadPiezas, Desperdicio=$restoMaterial m2');
}
