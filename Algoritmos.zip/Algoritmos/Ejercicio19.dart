// Ejercicio 19: Repartir presupuesto anual entre áreas del hospital.
// Comentario: Se solicita presupuesto y se distribuye por porcentajes definidos.
import 'dart:io';

void main() {
  print('Digite el presupuesto anual total:');
  double montoTotal = double.parse(stdin.readLineSync()!);

  double areaCardio = montoTotal * 0.37;
  double areaNeurologia = montoTotal * 0.28;
  double areaOncologia = montoTotal * 0.35;

  print('El resultado es: Cardiología=$areaCardio, Neurología=$areaNeurologia, Oncología=$areaOncologia');
}
