
// Ejercicio 5: Calcular la calificación final de un alumno.
import 'dart:io'; // Se importa para leer datos del usuario

void main() {
  // Se piden los datos al usuario
  print('Digite el promedio de los módulos cursados:');
  double promedioModulos = double.parse(stdin.readLineSync()!);

  print('Digite la nota obtenida en la prueba final:');
  double notaPrueba = double.parse(stdin.readLineSync()!);

  print('Digite la valoración del proyecto final:');
  double notaProyecto = double.parse(stdin.readLineSync()!);

  // Se calcula la nota final con nuevos porcentajes
  double notaDefinitiva = (promedioModulos * 0.50) +
                          (notaPrueba * 0.35) +
                          (notaProyecto * 0.15);

  // Se muestra el resultado
  print('La nota definitiva del estudiante es: $notaDefinitiva');
}
