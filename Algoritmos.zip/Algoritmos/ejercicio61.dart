// Ejercicio 61: Multiplicación Rusa
// Diseñe un algoritmo o programa que permita calcular la multiplicación de dos números, utilizando el
// método de la multiplicación Rusa, el cual consiste en multiplicar por dos el multiplicando y dividir
// entre dos el multiplicador hasta que el multiplicador tome el valor 1. Durante este proceso, se deben
// sumar todos los multiplicandos correspondientes a multiplicadores impares y este resultado es el de
// la multiplicación.

import 'dart:io';

void main() {
  print('Ingrese el multiplicando:');
  int multiplicando = int.parse(stdin.readLineSync()!);

  print('Ingrese el multiplicador:');
  int multiplicador = int.parse(stdin.readLineSync()!);

  int resultado = multiplicacionRusa(multiplicando, multiplicador);
  print('El resultado de $multiplicando x $multiplicador es: $resultado');
}

int multiplicacionRusa(int multiplicando, int multiplicador) {
  int suma = 0;
  while (multiplicador >= 1) {
    if (multiplicador % 2 != 0) {
      suma += multiplicando;
    }
    multiplicando *= 2;
    multiplicador ~/= 2;
  }
  return suma;
}
